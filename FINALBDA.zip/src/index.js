import React, { Fragment } from "react";
import ReactDOM from "react-dom/client";
import "./index.css";
import App from "./App";
import { StyledEngineProvider } from "@mui/material/styles";
import SelectVariants from "./components/SelectVariants";
import Variantmodal from  "./components/Variantmodal";
import Preview from "./components/Preview";



const root = ReactDOM.createRoot(document.getElementById("root"));
root.render(
  <Fragment>
    <StyledEngineProvider injectFirst>
      <App/>
      {/* <SelectVariants/> */}
      {/* <Variantmodal/> */}
      {/* <Preview/> */}
    </StyledEngineProvider>
  </Fragment>
);

