import Sidebar from "./components/SideBar";
import HeaderBar from "./components/HeaderBar";
import ClauseDnd from "./components/ClauseDnd";

function App() {
  return (
    <div>
      <HeaderBar /> 
       {/* <Sidebar /> */}
       <ClauseDnd />
       
    </div>
  )
}

export default App