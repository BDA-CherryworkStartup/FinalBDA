import { IconButton, Stack, TextField, Typography } from "@mui/material";
import * as React from 'react';
import { useEffect, useState } from "react";
import { DragDropContext, Draggable, Droppable } from "react-beautiful-dnd";
import { v4 as uuid } from "uuid";
import VisibilityOutlinedIcon from "@mui/icons-material/VisibilityOutlined";
import ModeEditOutlinedIcon from "@mui/icons-material/ModeEditOutlined";
import DeleteOutlineOutlinedIcon from "@mui/icons-material/DeleteOutlineOutlined";
import Box from "@mui/material/Box";
import Modal from "@mui/material/Modal";
import Collapse from "@kunukn/react-collapse";
import Accordion from "@mui/material/Accordion";
import AccordionSummary from "@mui/material/AccordionSummary";
import AccordionDetails from "@mui/material/AccordionDetails";
import ExpandMoreIcon from "@mui/icons-material/ExpandMore";
import Card from '@mui/material/Card';
import CardActions from '@mui/material/CardActions';
import CardContent from '@mui/material/CardContent';
import Button from "@mui/material/Button";
import SelectVariants from "./SelectVariants";
import VariantModal from "./Variantmodal";
// import { clauses } from '../data/clauses'
import EditClause from "./EditClause";
import _ from "lodash";
import { ParaglidingSharp } from "@mui/icons-material";
import DescriptionOutlinedIcon from '@mui/icons-material/DescriptionOutlined';
import CompareIcon from '@mui/icons-material/Compare';

const style = {
  position: "absolute",
  top: "50%",
  left: "50%",
  transform: "translate(-50%, -50%)",
  width: 400,
  bgcolor: "background.paper",
  border: "2px solid #000",
  boxShadow: 24,
  p: 4,
};

function ClauseDnd() {
  const [clausesList, setClausesList] = useState([]);
  const [apiClauseList, setApiClauseList] = useState([]);
  const [deleteIndex, setDeleteIndex] = useState(-1);
  const [deleteButtonClicked, setDeleteButtonClicked] = useState(false);
  const handleSubmit = () => console.log(selectedClause);
  const [clauses,setClauses]=useState([]);
  const [preview,setPreview]=useState(false);
 
  

const columnsFromBackend = {
    1: {
      name: "New Document",
      items: clausesList,
    },
    2: {
      name: "Clause Library",
      items: apiClauseList,
    },
  };

useEffect(()=> {
    if(deleteButtonClicked) {
      let clausesListCopy = clausesList
      _.remove(clausesListCopy, (c) => c.id !== deleteIndex)
      setClausesList(clausesListCopy)
    }
  }, [deleteButtonClicked])
 
  const [columns, setColumns] = useState(columnsFromBackend);
  const [fieldsData, setFieldsData] = useState([]);
  const [selectedClause, setSelectedClause] = useState([]);
  const [openEditScreen,setOpenEditScreen] = useState(false);
  const [openCompareScreen,setOpenCompareScreen] = useState(false);
  const [compareIndex,setCompareIndex]=useState(-1);
  const [previewScreen,SetPreviewScreen]=useState(false);
  
// Fetch list of clauses from the backend on the first render
useEffect(()=>{ 
    fetch("https://bda-test-3.azurewebsites.net/api/clause")
    .then((response) => response.json())
    .then((data) => {
      let temp={...columns};
      temp["2"].items=data.result;
      setColumns(temp);
      setApiClauseList(data.result);
    })
},[])

const fetchClauseData = (clauseId) => {
  console.log('clause details to be fetched: ', clauseId)
  fetch("https://bda-test-3.azurewebsites.net/api/clause/"+clauseId)
  .then((response) => response.json())
  .then((data) => {
    let tempClauses=[...clauses];
    tempClauses.push({variant:data.variantResults});
    setClauses(tempClauses);
   let index=data.variantResults.findIndex(ele=>ele.variantDefault===true);
   let tempclauseList=[...clausesList];
   tempclauseList.push(data.variantResults[index]);
   console.log(tempclauseList)
   setClausesList(tempclauseList);
  })
}
  

const onDragEnd = (result, columns, setColumns) => {
    const { source, destination } = result;
    if (!destination || source.droppableId === destination.droppableId) return;

    if (source.droppableId !== destination.droppableId) {
      const sourceColumn = columns[source.droppableId];
      const destColumn = columns[destination.droppableId];
      // const sourceItems = [...sourceColumn.items];

      const destItems = [...destColumn.items];
      // let removed = apiClauseList[source.index];
      let removed = clauses[source.index];
      removed = { id: uuid(), ...removed};
      // removed = { ...removed};
      
      // console.log('source index: ', source.index)
      destItems.push(removed);
      setClausesList(destItems);
      fetchClauseData(result.draggableId);

      setColumns({
        ...columns,
        [source.droppableId]: {
          ...sourceColumn,
          // items: apiClauseList,
            items: clauses,
        },
        [destination.droppableId]: {
          ...destColumn,
          items: destItems,
        },
      });
      
      console.log("clausesList:::::::", clausesList)
    }
    //  else {
    //   const column = columns[source.droppableId];
    //   const copiedItems = [...column.items];
    //   const [removed] = copiedItems.splice(source.index, 1);
    //   copiedItems.splice(destination.index, 0, removed);
    //   setColumns({
    //     ...columns,
    //     [source.droppableId]: {
    //       ...column,
    //       items: copiedItems,
    //     },
    //   });
    // }
  };

  const handleChangeParameters = (index) => {
    console.log("Called from EditClause")
    const changeClauseList = [...clausesList];
    let content = "" + changeClauseList[index].content;
    console.log(content);
    fieldsData.forEach(field => {
      console.log(`$$${field.name}$$` + "\n" + field)
      content = content.replace(`$$${field.name}$$`, field.value)
    });
    console.log(fieldsData);
    console.log(content);
    changeClauseList[index].content = content;
    setClausesList(changeClauseList);
  }
  const compareButton = (index) =>{
    setCompareIndex(index);
    if(compareIndex!==-1 && index===compareIndex){
      setCompareIndex(-1);
    }
  }
  
 
return (
    <div style={{ display: "flex", justifyContent: "space-between", height: "100%", flexDirection:"row-reverse"}}>

      {/* --------- EDIT CLAUSE ------------- */}
      <div
        style={{
          display: "flex",
          flexDirection: "column",
          alignItems: "center",
          width: "25vw",
        }}
      >
        <Stack>
          {selectedClause && ( <EditClause 
           fieldsData={[...fieldsData]} 
           setFieldsData={setFieldsData}
            setOpenEditScreen={setOpenEditScreen} 
            openEditScreen={openEditScreen} 
            handleChangeParameters={handleChangeParameters} 
            selectedIndex={selectedClause.index}/> )}
        </Stack>
      </div>

      {/* ------------ NEW DOCUMENT -------------- */}
      
      <DragDropContext
        onDragEnd={(result) => onDragEnd(result, columns, setColumns)}>
        <div
          style={{
            display: "flex",
            flexDirection: "column",
            alignItems: "center",
          }}
        >
          <h2>Create New Document</h2>
          <Stack direction="row" alignItems="center" spacing={2}>
          <Button onClick={handleSubmit}>Submit</Button>
          <Button align>Save Draft</Button>
          <Button onClick={setPreview}>Preview</Button>
          </Stack>
          <div className="hideScroll" style={{ margin:8}}>
          <Card sx={{ minWidth: 60 ,flex:1, backgroundColor:'#FBFCF8'}}>
          <CardContent>
         
     
          {(!preview) &&
            <Droppable droppableId="1">
              {(provided, snapshot) => (
                <div
                  className="hideScroll"
                  {...provided.droppableProps}
                  ref={provided.innerRef}
                  style={{
                    background: snapshot.isDraggingOver
                      ? "white"
                      : "white",
                    padding: 8,
                    width: "50vw",
                    maxHeight: 800,
                    minHeight: 800,
                    overflowY: "scroll",
                  }}
                >
                   
                  {clausesList.map((item, index) => (
                    <div
                      className="hideScroll"
                      style={{
                        userSelect: "none",
                        padding: 16,
                        margin: "0 0 8px 0",
                        minHeight: "100px",
                        backgroundColor: "#FBFCF8",
                        color: "white",
                      }}
                    >
                  
                     <Stack alignItems="center" justifyContent="center">
                        {item.variantName}
                        
                        <Stack
                          direction="row"
                          justifyContent="space-around"
                          alignItems="center"
                        >
                          {/* <IconButton>
                            <VisibilityOutlinedIcon size="small" />
                          </IconButton> */}
                          <CardActions>
                          <IconButton
                            onClick={() => {
                              setSelectedClause({ data : item, index : index});
                              let fields = structuredClone(item.parameters);
                              setFieldsData(fields);
                              setOpenEditScreen(true);
                            }}
                            size="large"
                          ><ModeEditOutlinedIcon size ="small"/></IconButton>
                          <IconButton
                            onClick={() => {
                              setDeleteButtonClicked(true);
                              setDeleteIndex(item.id);
                              
                            }}
                          ><DeleteOutlineOutlinedIcon size="small" /></IconButton>
                          <IconButton
                          onClick={() => {
                            compareButton(index);
                          }}
                          size="large">
                            <CompareIcon size ="small"/>
                          </IconButton>
                          </CardActions>
                        </Stack>
                      </Stack>
            
                      {/* -- clause accordian */}
                      <div>
                        <Accordion>
                          <AccordionSummary expandIcon={<VisibilityOutlinedIcon size="small" />}>
                            <Typography>
                              {item.content}
                            </Typography>
                          </AccordionSummary>
                          <AccordionDetails>
                            <Typography>
                              {/* {getFieldValues(
                                item.paragraph,
                                item.dynamicFields,
                                item.id
                              )} */}
                            </Typography>
                          </AccordionDetails>
                        </Accordion>
                        
                      </div>
                      
                      {compareIndex===index &&<Stack alignItems="center" justifyContent="center">
                        <SelectVariants 
                        clausesList={clausesList} 
                        variants={clauses[index]?.variant} 
                        setClausesList={setClausesList} 
                        setOpenCompareScreen={setOpenCompareScreen} 
                        openCompareScreen={openCompareScreen}
                        clauseId={item.id} 
                        setCompareIndex={setCompareIndex}
                        rowId={index}/>
                      </Stack>}

                      <Stack alignItems="center" justifyContent="center">
                        <VariantModal 
                        clausesList={clausesList} 
                        variants={clauses[index]?.variant} 
                        index={index}
                        setClausesList={setClausesList} 
                        clauseId={item.id} 
                        rowId={index}/>
                      </Stack>
                      
                    </div>
                  ))}
                           
                  {provided.placeholder}
                </div>
              )}
          
            </Droppable>
}
            {preview && <Box
              sx={{
                width:"60rem",
                height: 1000,
                borderStyle:"dashed",
                borderColor:'black',
                opacity: [0.9, 0.8, 0.7],  
              }}
              ><Stack>
                  <Stack>
                  {clausesList?.map((item) => (
                      <Typography id="modal-modal-title" variant="h6" component="h2" color="#000000" lineHeight="3">
                      {item.content}
                      </Typography>
                  ))}                              
                  </Stack>  
              </Stack>
              </Box> 
            } 
            </CardContent>
            </Card>
          </div>
        </div>

        {/* ---------- CLAUSE LIBRARY ----------- */}
        <div
          style={{
            display: "flex",
            flexDirection: "column",
            alignItems: "center",
            
          }}
        >
          <h2>Clause Library</h2>
          <div className="hideScroll" style={{ marginTop: 45 }}  >
          
            <Droppable droppableId="2">
              {(provided, snapshot) => (
                <div
                  className="hideScroll"
                  {...provided.droppableProps}
                  ref={provided.innerRef}
                  
                  style={{
                    background: snapshot.isDraggingOver
                      ? "#ffffff"
                      : "#ffffff",
                    padding: 8,
                    width: "18vw",
                    maxHeight: 1030,
                    minHeight: 1030,
                    overflowY: "scroll",
                    overflowX: "hidden",
                  }}
                >
                  
                  {apiClauseList.map((item, index) => (
                    <Draggable style={{
                      justifyContent:"center",
                      alignItems:"center",
                    }}
                      key={item.id}
                      draggableId={item.id}
                      index={index}
                      
                    >
                      {(provided, snapshot) => (
                        <div
                          className="hideScroll"
                          // startIcon={<DescriptionOutlinedIcon />}
                          {...provided.draggableProps}
                          {...provided.dragHandleProps}
                          ref={provided.innerRef}
                          style={{
                            userSelect: "none",
                            padding: "1px",
                            margin: "0 0 8px 0",
                            minHeight: "55px",
                            borderStyle:"solid",
                            borderWidth:1,
                            borderBlockColor:"black",
                            borderRadius:"6px",
                            width:"18rem",
                            backgroundColor: snapshot.isDragging
                              ? "#ffffff"
                              : "#ffffff",
                            color: "black",
                            ...provided.draggableProps.style,
                          }}
                        >
                          <Stack alignItems="center" justifyContent="center" padding="14px" >
                            {item.name}
                          </Stack>
                        </div>
                      )}
                    </Draggable>
                  ))}
                        
                  {provided.placeholder}
                </div>
              )}
            </Droppable>
            
            
          </div>
          
            {/* {preview && <Box
            sx={{
              width: 300,
              height: 300,
              borderStyle:"dashed",
              borderColor:'black',
              opacity: [0.9, 0.8, 0.7],  
            }}
            >

            <Stack>
                <Stack>
                {clausesList?.map((item) => (
                    <Typography id="modal-modal-title" variant="h6" component="h2">
                    {item.content}
                    </Typography>
                ))}                              
                </Stack>  
            </Stack>
            </Box> } */}
            
        </div>
        
      </DragDropContext>
    </div>
  );
}

export default ClauseDnd;
