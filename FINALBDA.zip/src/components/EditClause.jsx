import { IconButton, Stack, TextField, Typography } from "@mui/material";
import * as React from "react";
import { useState } from "react";
import { DragDropContext, Draggable, Droppable } from "react-beautiful-dnd";
import { v4 as uuid } from "uuid";
import VisibilityOutlinedIcon from "@mui/icons-material/VisibilityOutlined";
import ModeEditOutlinedIcon from "@mui/icons-material/ModeEditOutlined";
import DeleteOutlineOutlinedIcon from "@mui/icons-material/DeleteOutlineOutlined";
import Box from "@mui/material/Box";
import Modal from "@mui/material/Modal";
import Collapse from "@kunukn/react-collapse";
import Accordion from "@mui/material/Accordion";
import AccordionSummary from "@mui/material/AccordionSummary";
import AccordionDetails from "@mui/material/AccordionDetails";
import ExpandMoreIcon from "@mui/icons-material/ExpandMore";
import Button from "@mui/material/Button";
import SelectVariants from "./SelectVariants";
import { clauses } from "../data/clauses";
import ClauseDnd from "./ClauseDnd";
import Dialog from '@mui/material/Dialog';
import DialogActions from '@mui/material/DialogActions';
import DialogContent from '@mui/material/DialogContent';
import DialogContentText from '@mui/material/DialogContentText';
import DialogTitle from '@mui/material/DialogTitle';

const style = {
  position: "absolute",
  top: "50%",
  left: "50%",
  transform: "translate(-50%, -50%)",
  width: 400,
  bgcolor: "background.paper",
  border: "2px solid #000",
  boxShadow: 24,
  p: 4,
};

export default function EditClause({
  fieldsData,
  setFieldsData,
  handleChangeParameters,
  selectedIndex,
  openEditScreen,
  setOpenEditScreen
}) {
  console.log(selectedIndex);
  const [selectedClause, setSelectedClause] = useState(null);
  const [open, setOpen] = useState(false);

  const handleOpen = () => {
    setOpen(true);
  };

  const handleClose = () => {
    setOpenEditScreen(false);
  };

  const onFieldValueChange = (e, index) => {
    const newData = [...fieldsData];
    newData[index].value = e.target.value;
    setFieldsData(newData);
  };

  return (
    <div>
      <Dialog open={openEditScreen} onClose={handleClose}>
          <DialogTitle>Field Settings</DialogTitle>
          {fieldsData.map((ele, index) => (
            <DialogContent key={index}>
              <DialogContentText variant="subtitle1" sx={{ mt: 2 }}>
                {ele.label}
              </DialogContentText>
              <TextField
                autoFocus
                margin="dense"
                fullWidth
                variant="outlined"
                value={ele.value}
                placeholder={ele.name}
                onChange={(e) => onFieldValueChange(e, index)}
              />
            </DialogContent> 
            
          ))}
          <DialogActions>
            <Button
              onClick={() => {
                handleChangeParameters(selectedIndex);
              }}>Save</Button>
            <Button
              onClick={() => {
                setSelectedClause(null);
                setFieldsData([]);
              }}>Discard</Button>
          </DialogActions>
          </Dialog>
        
    </div>
  );
}
