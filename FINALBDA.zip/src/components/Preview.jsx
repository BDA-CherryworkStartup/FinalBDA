// // import React, { useState } from 'react';
// import * as React from 'react';
// import {Box,Stack,Typography,Button} from '@mui/material';
// import { useState } from "react";

// // function DocumentPreview() {
// //   const [documentText, setDocumentText] = useState('');
// //   const [clauses, setClauses] = useState([]);

// //   const handleAddClause = () => {
// //     setClauses([...clauses, 'New clause']);
// //   };

// //   const handleDeleteClause = (index) => {
// //     const newClauses = [...clauses];
// //     newClauses.splice(index, 1);
// //     setClauses(newClauses);
// //   };

// //   return (
// //    <div>
// //      <h2>Edit Document</h2>
// // //       <textarea
// //         value={documentText}
// //         onChange={(e) => setDocumentText(e.target.value)}
// //       />
// //       <h3>Clauses:</h3>
// //       <button onClick={handleAddClause}>Add Clause</button>
// //       {clauses.map((clause, index) => (
// //         <div key={index}>
// //           <input
// //             type="text"
// //             value={clause}
// //             onChange={(e) => {
// //               const newClauses = [...clauses];
// //               newClauses[index] = e.target.value;
// //               setClauses(newClauses);
// //             }}
// //           />
// //           <button onClick={() => handleDeleteClause(index)}>Delete</button>
// //         </div>
// //       ))}
// //       <h3>Preview:</h3>
// //       <div>{documentText}</div>
// //       {clauses.map((clause, index) => (
// //         <div key={index}>{clause}</div>
// //       ))}
// //     </div>
// //   );
// // }

// // export default DocumentPreview;


// //New
// function Preview(){
// const [clausesList, setClausesList] = useState([]);


//  <Box
// sx={{
//   width: 300,
//   height: 300,
//   borderStyle:"dashed",
//   borderColor:'black',
//   opacity: [0.9, 0.8, 0.7],  
// }}
// >
// <Button>Preview</Button>
// <Stack>
//   <Button>Preview</Button>
//     <Stack>
//     {clausesList?.map((item) => (
//         <Typography id="modal-modal-title" variant="h6" component="h2">
//         {item.content}
//         </Typography>
//     ))}                              
//     </Stack>  
// </Stack>
// </Box> 
// }
 
// export default Preview;